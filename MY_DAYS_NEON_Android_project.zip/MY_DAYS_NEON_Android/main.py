import json, calendar, os
from datetime import date
from kivy.app import App
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.popup import Popup
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.core.window import Window

THEMES = {
    "Neon Blue": ["080B16","101629","151E35","263655","EDF3FF","8292B5","54E5FF","9B7BFF"],
    "Neon Purple": ["0D0918","171027","211638","49336B","F4EEFF","A99ABC","C69BFF","FF70D6"],
    "Neon Green": ["07130F","0E201A","153027","285844","E9FFF4","83A997","65F5B5","8AD9FF"],
    "Neon Pink": ["160A13","24111F","32182C","653453","FFF0FA","B995AA","FF8DD6","B99BFF"],
}
RATING_COLORS = ["FF5C75","FF9A52","F4D76B","4BE0A0","5C9DFF"]
LABELS = ["Плохо","Ниже обычного","Средне","Хорошо","Отлично"]
MONTHS = ["Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь"]
WEEKDAYS = ["ПН","ВТ","СР","ЧТ","ПТ","СБ","ВС"]

def hx(value):
    return tuple(int(value[i:i+2],16)/255 for i in (0,2,4)) + (1,)

class NeonButton(Button):
    def __init__(self, app, accent=False, **kwargs):
        self.app_ref = app
        self.accent = accent
        super().__init__(**kwargs)
        self.background_normal = ""
        self.background_down = ""
        self.background_color = hx(app.palette[6] if accent else app.palette[2])
        self.color = hx(app.palette[0] if accent else app.palette[4])
        self.font_size = "14sp"
        self.size_hint_y = None
        self.height = dp(46)

class MyDaysApp(App):
    title = "MY DAYS — NEON"
    def build(self):
        Window.clearcolor = hx(THEMES["Neon Blue"][0])
        self.theme_name = "Neon Blue"
        self.palette = THEMES[self.theme_name]
        self.today = date.today()
        self.selected = self.today.isoformat()
        self.year, self.month = self.today.year, self.today.month
        self.data_path = os.path.join(self.user_data_dir, "my_days_data.json")
        self.settings_path = os.path.join(self.user_data_dir, "settings.json")
        self.data = self.load_data()
        try:
            self.theme_name = json.load(open(self.settings_path, encoding="utf-8")).get("theme","Neon Blue")
            self.palette = THEMES.get(self.theme_name, THEMES["Neon Blue"])
        except Exception: pass
        self.sm = ScreenManager()
        for name in ("calendar","stats","timeline"):
            self.sm.add_widget(Screen(name=name))
        self.build_calendar_screen()
        self.build_stats_screen()
        self.build_timeline_screen()
        self.refresh_all()
        return self.sm

    def load_data(self):
        try:
            with open(self.data_path, encoding="utf-8") as f:
                obj = json.load(f)
                return obj if isinstance(obj, dict) else {}
        except Exception: return {}

    def save_data(self):
        os.makedirs(self.user_data_dir, exist_ok=True)
        tmp = self.data_path + ".tmp"
        with open(tmp,"w",encoding="utf-8") as f:
            json.dump(self.data,f,ensure_ascii=False,indent=2)
        os.replace(tmp,self.data_path)

    def key(self,y,m,d): return f"{y:04d}-{m:02d}-{d:02d}"
    def rec(self): return self.data.get(self.selected,{})

    def make_root(self, screen, title):
        outer=BoxLayout(orientation="vertical",padding=dp(14),spacing=dp(10))
        outer.add_widget(Label(text=f"[b]MY DAYS[/b]  [color={self.palette[6]}]NEON[/color]",markup=True,
                               size_hint_y=None,height=dp(38),font_size="22sp",color=hx(self.palette[4])))
        outer.add_widget(Label(text=title,size_hint_y=None,height=dp(30),font_size="18sp",color=hx(self.palette[4])))
        screen.add_widget(outer)
        return outer

    def nav(self, parent):
        bar=BoxLayout(size_hint_y=None,height=dp(48),spacing=dp(6))
        for label,name in (("Календарь","calendar"),("Статистика","stats"),("Лента","timeline")):
            b=NeonButton(self,text=label)
            b.bind(on_release=lambda _,n=name:self.go(n))
            bar.add_widget(b)
        parent.add_widget(bar)

    def build_calendar_screen(self):
        s=self.sm.get_screen("calendar")
        root=self.make_root(s,"ТВОЯ ИСТОРИЯ")
        monthbar=BoxLayout(size_hint_y=None,height=dp(44),spacing=dp(8))
        prev=NeonButton(self,text="‹"); prev.bind(on_release=lambda *_:self.change_month(-1))
        nxt=NeonButton(self,text="›"); nxt.bind(on_release=lambda *_:self.change_month(1))
        self.month_label=Label(color=hx(self.palette[4]),font_size="16sp")
        monthbar.add_widget(prev); monthbar.add_widget(self.month_label); monthbar.add_widget(nxt)
        root.add_widget(monthbar)
        self.calendar_grid=GridLayout(cols=7,spacing=dp(4),size_hint_y=None)
        self.calendar_grid.bind(minimum_height=self.calendar_grid.setter("height"))
        sc=ScrollView(size_hint_y=None,height=dp(250),do_scroll_x=False)
        sc.add_widget(self.calendar_grid); root.add_widget(sc)
        self.selected_info=Label(text="",size_hint_y=None,height=dp(26),color=hx(self.palette[6]))
        root.add_widget(self.selected_info)
        ratings=GridLayout(cols=5,spacing=dp(5),size_hint_y=None,height=dp(44))
        self.rating_buttons=[]
        for i in range(1,6):
            b=NeonButton(self,text=str(i)); b.background_color=hx(RATING_COLORS[i-1])
            b.color=hx("080B16"); b.bind(on_release=lambda _,n=i:self.set_rating(n))
            ratings.add_widget(b); self.rating_buttons.append(b)
        root.add_widget(ratings)
        self.rating_label=Label(size_hint_y=None,height=dp(22),color=hx(self.palette[5]))
        root.add_widget(self.rating_label)
        self.note=TextInput(hint_text="Заметки о дне…",multiline=True,size_hint_y=None,height=dp(110),
                            background_color=hx(self.palette[2]),foreground_color=hx(self.palette[4]),
                            cursor_color=hx(self.palette[6]),padding=dp(10))
        self.note.bind(text=lambda *_:self.save_editor())
        root.add_widget(self.note)
        self.tags=TextInput(hint_text="Теги через запятую",multiline=False,size_hint_y=None,height=dp(42),
                            background_color=hx(self.palette[2]),foreground_color=hx(self.palette[4]))
        self.tags.bind(text=lambda *_:self.save_editor())
        root.add_widget(self.tags)
        self.star=NeonButton(self,text="☆ Выдающийся день")
        self.star.bind(on_release=lambda *_:self.toggle_star()); root.add_widget(self.star)
        tools=BoxLayout(size_hint_y=None,height=dp(44),spacing=dp(6))
        today=NeonButton(self,text="Сегодня"); today.bind(on_release=lambda *_:self.go_today())
        theme=Spinner(text=self.theme_name,values=list(THEMES.keys()),size_hint_x=1)
        theme.bind(text=lambda _,v:self.set_theme(v))
        tools.add_widget(today); tools.add_widget(theme); root.add_widget(tools)
        self.nav(root)

    def render_calendar(self):
        self.month_label.text=f"{MONTHS[self.month-1]} {self.year}"
        g=self.calendar_grid; g.clear_widgets()
        for wd in WEEKDAYS:
            g.add_widget(Label(text=wd,color=hx(self.palette[5]),size_hint_y=None,height=dp(28)))
        weeks=calendar.monthcalendar(self.year,self.month)
        for week in weeks:
            for d in week:
                if not d:
                    g.add_widget(Label(text="",size_hint_y=None,height=dp(42))); continue
                k=self.key(self.year,self.month,d); rec=self.data.get(k,{})
                rating=rec.get("rating")
                caption=str(d)+(" ★" if rec.get("standout") else "")
                b=NeonButton(self,text=caption)
                b.height=dp(42)
                b.background_color=hx(RATING_COLORS[rating-1] if rating in range(1,6) else self.palette[2])
                b.color=hx("080B16" if rating else self.palette[4])
                if k==self.selected: b.background_color=hx(self.palette[6])
                b.bind(on_release=lambda _,key=k:self.select_day(key))
                g.add_widget(b)
        self.load_editor()

    def select_day(self,k):
        self.save_editor()
        self.selected=k; dt=date.fromisoformat(k); self.year,self.month=dt.year,dt.month
        self.render_calendar()

    def load_editor(self):
        if not hasattr(self,"note"): return
        r=self.rec()
        self.selected_info.text=date.fromisoformat(self.selected).strftime("%d.%m.%Y")
        self.note.text=r.get("note","")
        self.tags.text=", ".join(r.get("tags",[]))
        rating=r.get("rating")
        self.rating_label.text=f"{rating}/5 · {LABELS[rating-1]}" if rating in range(1,6) else "Оценка ещё не выбрана"
        self.star.text="★ Выдающийся день отмечен" if r.get("standout") else "☆ Выдающийся день"

    def save_editor(self,*_):
        if not hasattr(self,"note"): return
        r=self.data.setdefault(self.selected,{})
        r["note"]=self.note.text
        tags=list(dict.fromkeys(t.strip().lstrip("#") for t in self.tags.text.split(",") if t.strip()))
        if tags:r["tags"]=tags
        else:r.pop("tags",None)
        if not r.get("note","").strip() and not r.get("rating") and not r.get("standout") and not r.get("tags"):
            self.data.pop(self.selected,None)
        self.save_data()

    def set_rating(self,n):
        self.save_editor(); r=self.data.setdefault(self.selected,{})
        r["rating"]=n; self.save_data(); self.refresh_all()

    def toggle_star(self):
        self.save_editor(); r=self.data.setdefault(self.selected,{})
        r["standout"]=not r.get("standout",False)
        if not r["standout"]:r.pop("standout",None)
        self.save_data(); self.refresh_all()

    def change_month(self,delta):
        self.save_editor(); self.month+=delta
        if self.month<1:self.month=12;self.year-=1
        if self.month>12:self.month=1;self.year+=1
        self.selected=self.key(self.year,self.month,1); self.render_calendar()

    def go_today(self):
        self.save_editor();self.selected=self.today.isoformat()
        self.year,self.month=self.today.year,self.today.month;self.render_calendar()

    def build_stats_screen(self):
        s=self.sm.get_screen("stats"); root=self.make_root(s,"ТВОИ РЕЗУЛЬТАТЫ")
        self.stats_text=Label(text="",halign="left",valign="top",color=hx(self.palette[4]))
        root.add_widget(self.stats_text); self.nav(root)

    def build_timeline_screen(self):
        s=self.sm.get_screen("timeline"); root=self.make_root(s,"ТВОИ ВОСПОМИНАНИЯ")
        self.timeline_box=BoxLayout(orientation="vertical",spacing=dp(6))
        scroll=ScrollView();scroll.add_widget(self.timeline_box);root.add_widget(scroll)
        self.nav(root)

    def refresh_stats(self):
        rated=[(k,v) for k,v in self.data.items() if v.get("rating") in range(1,6)]
        vals=[v["rating"] for _,v in rated]
        avg=sum(vals)/len(vals) if vals else 0
        good=sum(v>=4 for v in vals)
        by={}
        for k,v in rated:
            dt=date.fromisoformat(k);by.setdefault((dt.year,dt.month),[]).append(v["rating"])
        best=max(by,key=lambda x:sum(by[x])/len(by[x])) if by else None
        best_text=f"{MONTHS[best[1]-1]} {best[0]}" if best else "—"
        self.stats_text.text=(f"Средняя оценка: {avg:.2f}/5\n\n"
            f"Хорошие дни (4–5): {good/len(vals)*100:.0f}%" if vals else "Пока нет оценок.")
        if vals:self.stats_text.text+=f"\nЗаполнено дней с оценкой: {len(vals)}\nЛучший месяц: {best_text}"

    def refresh_timeline(self):
        self.timeline_box.clear_widgets()
        rows=[]
        for k,r in self.data.items():
            if r.get("rating") or r.get("note","").strip() or r.get("tags") or r.get("standout"):
                rows.append((k,r))
        for k,r in sorted(rows,reverse=True):
            rating=f" · {r['rating']}/5" if r.get("rating") else ""
            tags="  #"+ " #".join(r.get("tags",[])) if r.get("tags") else ""
            note=" — "+r.get("note","").replace("\n"," ")[:100] if r.get("note","").strip() else ""
            b=NeonButton(self,text=("★ " if r.get("standout") else "")+k+rating+tags+note)
            b.bind(on_release=lambda _,key=k:self.open_day(key));self.timeline_box.add_widget(b)

    def open_day(self,k):
        self.selected=k;dt=date.fromisoformat(k);self.year,self.month=dt.year,dt.month
        self.go("calendar");self.render_calendar()

    def refresh_all(self):
        if hasattr(self,"calendar_grid"):self.render_calendar()
        if hasattr(self,"stats_text"):self.refresh_stats()
        if hasattr(self,"timeline_box"):self.refresh_timeline()

    def go(self,name):
        self.save_editor();self.sm.current=name
        self.refresh_all()

    def set_theme(self,name):
        if name not in THEMES or name==self.theme_name:return
        self.theme_name=name;self.palette=THEMES[name]
        with open(self.settings_path,"w",encoding="utf-8") as f:json.dump({"theme":name},f)
        # Rebuild widgets so every surface adopts the selected palette.
        current=self.sm.current
        self.sm.clear_widgets()
        for n in ("calendar","stats","timeline"):self.sm.add_widget(Screen(name=n))
        self.build_calendar_screen();self.build_stats_screen();self.build_timeline_screen()
        self.sm.current=current;self.refresh_all()

    def on_stop(self):
        self.save_data()

if __name__ == "__main__":
    MyDaysApp().run()
