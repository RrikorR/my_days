[app]
title = MY DAYS NEON
package.name = mydaysneon
package.domain = app.mydays
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,json,txt
version = 2.1.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0
android.api = 35
android.minapi = 23
android.archs = arm64-v8a
android.permissions = READ_MEDIA_IMAGES
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
